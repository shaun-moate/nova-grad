# nova-grad
A basic library to support the development of neural networks (initially... maybe other stuff in the future :shrug:)

Inspired by micrograd and tinygrad.  Doing to learn more about the world of AI
