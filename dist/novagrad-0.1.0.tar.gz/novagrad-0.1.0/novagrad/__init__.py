# TODO: with the basic set up, attempt to leverage for Digit Recognition (implement in examples)
# https://www.kaggle.com/competitions/digit-recognizer/
